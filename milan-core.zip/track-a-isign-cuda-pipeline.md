## 5.5 Data & Training Strategy — iSign, CUDA Pipeline (revised)

**Decision:** iSign (228GB, Exploration-Lab/iSign on Hugging Face) is now the sole primary dataset. INCLUDE is dropped from the critical path — kept only as an optional later baseline (§ note at bottom), not a blocking dependency. This section replaces T-A3–T-A7 with a pipeline shaped around what iSign actually ships: video, pre-extracted poses, and aligned text, so GPU time goes to training, not to re-deriving landmarks MediaPipe would give you anyway.

---

### Stage 1 — Acquire and reconcile the schema (T-A1, revised)

1. Download and reassemble the three iSign components on the DGX:
   ```bash
   cat iSign-poses_v1.1_part_aa iSign-poses_v1.1_part_ab iSign-poses_v1.1_part_ac iSign-poses_v1.1_part_ad > iSign-poses_v1.1.zip
   unzip iSign-poses_v1.1.zip
   pip install pose-format --break-system-packages   # if not already in environment.yml
   ```
   Video zips only needed if you plan any visual QA or fallback re-extraction — not needed for the main training path.

2. **Critical check before anything else is built**: load a handful of `.pose` files and inspect what keypoint layout `pose-format` actually gives you:
   ```python
   from pose_format import Pose
   data = open("sample.pose", "rb").read()
   pose = Pose.read(data)
   print(pose.body.data.shape)       # (frames, people, keypoints, xyz/xyc)
   print(pose.header.components)     # which keypoint sets: pose/hand/face and their order
   ```
   This tells you the actual keypoint count, ordering, and confidence format. Write this down as `landmark_schema.md` — this is now derived from iSign's real pose format, not assumed from MediaPipe Holistic's docs.

3. **Decide the browser-side implication now**: your extension runs MediaPipe Tasks Vision (Web) live, which has its own keypoint ordering. If `pose-format`'s layout differs from MediaPipe Web's, you need a fixed index-mapping function (`remap_pose_to_web_schema()`) committed alongside the schema doc — this is a small, one-time function, not a re-extraction, but it must exist before T-B3 and T-A6 can trust the same input shape.

### Stage 2 — Build the training tensors (replaces old T-A3, much cheaper now)

Since pose data is already extracted, this stage is reshaping/caching, not running a model:

```python
# preprocessing/build_tensor_cache.py
# For each video_id in iSign_v1.1.csv:
#   - load the corresponding .pose file
#   - apply remap_pose_to_web_schema() if needed
#   - normalize per your locked convention (T-A1)
#   - save as a compact tensor: .npy or a WebDataset/tar shard
```

- Split strictly by `video_id` (per the dataset authors' own instructions), not by row — multiple text segments share a video and must stay together to avoid leakage.
- Cache to a **sharded format** (WebDataset `.tar` shards or a `.npz`/`.parquet` set) rather than millions of loose `.npy` files — on a shared DGX filesystem, hundreds of thousands of tiny files is a real I/O bottleneck during training; shards stream far better into a PyTorch `DataLoader`.
- This step is CPU/IO-bound, not GPU-bound. Run it once, verify the output, and never touch raw pose files again during training.

### Stage 3 — GPU environment setup (CUDA specifics)

Before any training script runs:

```bash
nvidia-smi                     # confirm driver + CUDA version visible to the OS
python -c "import torch; print(torch.__version__, torch.version.cuda, torch.cuda.is_available())"
```

The PyTorch build in `environment.yml` must be compiled against a CUDA version **≤** the driver's reported CUDA version (driver is backward-compatible, not forward-compatible). If `torch.version.cuda` doesn't line up with what `nvidia-smi` shows, fix this before Stage 4 — training "succeeding" on CPU silently is the single most common way to lose a day here.

For an H200 specifically: use a recent PyTorch build (2.3+) with CUDA 12.x — H200 support requires a modern enough toolkit; an old pinned PyTorch/CUDA combo may not recognize the device correctly even if `nvidia-smi` looks fine.

Mixed precision from the start:
```python
scaler = torch.cuda.amp.GradScaler()
with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
    output = model(batch)
    loss = criterion(output, target)
```
bf16 (not fp16) is the safer default on H200-class hardware — wider dynamic range, no `GradScaler` underflow tuning needed in practice, though keeping the scaler doesn't hurt.

### Stage 4 — Architecture validation, small scale (T-A6, unchanged in spirit)

Before spending real GPU-hours: take a small subset of the iSign tensor cache (a few hundred video-sentence pairs), and validate the **streaming-attention mechanism** itself — chunked/causal attention producing coherent partial captions — cheaply, on a single GPU, fast iteration loop. This is where you iterate on chunk size, window overlap, and model depth, not on the full dataset. Log wall-clock time per step here; it's your basis for estimating full-run time in Stage 5.

### Stage 5 — Full training run (replaces old T-A4+T-A7, now a single stage)

Since there's no separate INCLUDE-pretraining step gating this anymore, this becomes one continuous training stage directly on iSign:

```python
# slm/train_isign.py
# DataLoader reads sharded tensor cache from Stage 2
# Model: chunked/causal-attention encoder-decoder validated in Stage 4
# Loss: cross-entropy over target caption tokens (standard seq2seq)
# Optimizer: AdamW, warmup + cosine decay
# Mixed precision: bf16 autocast (Stage 3)
```

Practical CUDA-specific notes worth setting up correctly the first time, not after a failed run:
- **`tmux` always** — this is a multi-hour+ job; a dropped SSH session must not kill it.
- **Checkpoint every N steps to disk**, not just at the end — a DGX is shared infrastructure; jobs can get preempted or you may need the GPU back mid-run.
- **`pin_memory=True` and `num_workers>0`** on the DataLoader — with data already in a fast tensor/shard format, the model can easily become I/O-starved without this, wasting GPU idle time.
- **Log GPU utilization** (`nvidia-smi -l 5` in a second `tmux` pane, or `torch.cuda.memory_allocated()`) during the first run — if utilization is low and fluctuating, it's a data-loading bottleneck, not a compute one, and worth fixing before running longer variants.
- **Gradient accumulation** if the true batch size you want doesn't fit in memory at once — cleaner than silently training at a smaller batch size than intended.

Output: a checkpoint with a real, recorded accuracy/quality metric on held-out iSign data (BLEU/WER or whatever metric your evaluation harness in `evaluation/benchmark_isign.py` computes) — this is T-A7's original definition of done, now reached in one training stage instead of two.

### Stage 6 — Distill + quantize (T-A9, unchanged)

```python
# export/distill_quantize.py
# int8 dynamic or static quantization via torch.quantization or ONNX Runtime's quantize_dynamic
```
Run on GPU for the distillation training (if you do a separate smaller student model) or directly post-hoc quantize the trained model; either way, measure the accuracy delta against the Stage 5 checkpoint before accepting the smaller model.

### Stage 7 — Export to ONNX (T-A10, unchanged)

```python
torch.onnx.export(model, dummy_input, "model.onnx", opset_version=17, dynamic_axes={...})
```
Smoke-test with plain `onnxruntime` (Python) before handing off to `extension/models/` — confirms the export is valid independent of any browser-side issue.

---

### Where INCLUDE still fits (optional, non-blocking)

Kept only as a **stretch item**, not on the critical path:
- A quick isolated-sign classification baseline (train a small classifier on INCLUDE's 56.8GB), used purely for the judge-facing "isolated vs. continuous" comparison slide (old T-A11).
- Only pursued if Stage 5 finishes with time to spare — it no longer pretrains anything the main pipeline depends on, since Stage 5 now trains directly on iSign's own pose data.

### Net effect of this revision

- **One fewer hard dependency chain** — old T-A4 → T-A7 (INCLUDE pretrain gates iSign fine-tune) is gone; Stage 5 starts as soon as Stage 4's architecture is validated.
- **Stage 2 is much cheaper than before** — iSign ships poses already extracted, so the heavy MediaPipe-over-raw-video work is now only a possible fallback (if the schema reconciliation in Stage 1 fails and you must re-extract from iSign's videos yourself), not the default path.
- **The one real risk this introduces**: if `pose-format`'s keypoint schema turns out to be meaningfully different or lower-fidelity than MediaPipe Web's live extraction (fewer face landmarks, different hand model, lower frame rate), the model may learn on cleaner/richer input than it gets at inference time from the extension. Stage 1's schema check is the point where this gets caught — don't skip it to save a day, since it's cheaper to catch here than after Stage 5 training is complete.
